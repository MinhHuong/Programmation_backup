drop table DETAIL_RESERV;

drop table RESERVATIONS;

drop table TARIF;

drop table CALENDRIER;

drop table ETAPES_SEJOUR;

drop table CIRCUITS;

drop table TRANSPORT;

drop table HOTEL_RESIDENCE;

drop table SEJOURS;

drop table HEBERGEMENT;

drop table VILLES_ETAPES;

drop table PAYS;

drop table VALEUR_TEMP;

commit;