drop table	TARIFS;

drop table	CALENDRIER;

drop table	SEJOURS;

drop table	PAYS;

commit;