update	tarif
set		prix_ttc = 200
where	no_sem = '512010'
and		code_sejour = 'SSND07';