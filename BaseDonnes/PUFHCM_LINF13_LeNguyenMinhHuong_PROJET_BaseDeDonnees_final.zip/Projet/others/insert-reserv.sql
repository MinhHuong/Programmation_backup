delete from reservations;

insert into reservations values (	null, 'LE', 'ELISE', 
									'RUE MINH PHUNG, QUARTIER 10, DISTRICT 11', '00084',
									'HO CHI MINH', '090 8989 361', '24-DEC-2010',
									3, 2, 1, null, null, 0 );