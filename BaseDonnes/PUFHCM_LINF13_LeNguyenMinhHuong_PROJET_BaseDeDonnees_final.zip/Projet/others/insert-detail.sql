delete from detail_reserv;

insert into detail_reserv values ('512010', 1, 'SSND07', 0, 0, null );