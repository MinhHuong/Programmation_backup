delete from detail_reserv where code_sejour = 'NTDL15';

insert into detail_reserv values ('022011', 1, 'NTDL15', 0, 0, null );