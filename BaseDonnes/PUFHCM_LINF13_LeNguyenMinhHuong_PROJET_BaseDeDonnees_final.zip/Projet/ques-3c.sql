select	*
from	sejours
where	nom_sejour like '%SOLEIL%';