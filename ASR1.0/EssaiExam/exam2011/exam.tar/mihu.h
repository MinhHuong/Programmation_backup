#ifndef TAMTA_H
#define TAMTA_H
class tamta {
public:
tamta();
~tamta();
};
#endif
