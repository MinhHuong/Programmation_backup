#ifndef FILE_INFO_H
#define FILE_INFO_H
class file_info {
public:
file_info();
~file_info();
};
#endif
