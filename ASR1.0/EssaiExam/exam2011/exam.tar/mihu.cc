#include "tamta.h"
tamta::tamta() {
}
tamta::~tamta() {
}
