#include "ConcreteObserver.h"
using namespace std;

ConcreteObserver::ConcreteObserver() {}

ConcreteObserver::~ConcreteObserver() {}

void ConcreteObserver::update(Observable) {}
