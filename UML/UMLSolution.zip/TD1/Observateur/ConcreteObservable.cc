#include "ConcreteObservable.h"
using namespace std;

ConcreteObservable::ConcreteObservable() {
  
}

ConcreteObservable::~ConcreteObservable() {
  
}
