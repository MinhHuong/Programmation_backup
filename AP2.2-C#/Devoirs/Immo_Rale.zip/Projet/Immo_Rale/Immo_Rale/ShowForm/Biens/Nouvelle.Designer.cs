﻿namespace Immo_Rale.ShowForm.Biens
{
    partial class Nouvelle
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_nom = new System.Windows.Forms.TextBox();
            this.tb_prenom = new System.Windows.Forms.TextBox();
            this.tb_adresse_pro = new System.Windows.Forms.TextBox();
            this.tb_tel_fixe = new System.Windows.Forms.TextBox();
            this.tb_tel_mobile = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbb_ville_pro = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tb_surfacehabitable = new System.Windows.Forms.TextBox();
            this.tb_surfaceparcelle = new System.Windows.Forms.TextBox();
            this.tb_adresse_bien = new System.Windows.Forms.TextBox();
            this.cbb_type_habitation = new System.Windows.Forms.ComboBox();
            this.checkBox_cave = new System.Windows.Forms.CheckBox();
            this.checkBox_garage = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.numericUpDown_chambre = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_bains = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_Eau = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.numericUpDown_pieces = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.tb_complementaire = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tb_quartier = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tb_prix_souhait = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tb_prix_vente = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tb_acheteur = new System.Windows.Forms.TextBox();
            this.cbb_ville_bien = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tb_statut = new System.Windows.Forms.TextBox();
            this.bt_save = new System.Windows.Forms.Button();
            this.bt_annuler = new System.Windows.Forms.Button();
            this.dateTimePicker_reel = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_veut = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_chambre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_bains)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Eau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pieces)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(116, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Propriétaire";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(536, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(24, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nom";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(24, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Prénom";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(24, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Adresse";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(24, 214);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "Téléphone fixe";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(24, 254);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Téléphone mobile";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(24, 294);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Email";
            // 
            // tb_nom
            // 
            this.tb_nom.Location = new System.Drawing.Point(164, 54);
            this.tb_nom.Name = "tb_nom";
            this.tb_nom.Size = new System.Drawing.Size(135, 20);
            this.tb_nom.TabIndex = 2;
            // 
            // tb_prenom
            // 
            this.tb_prenom.Location = new System.Drawing.Point(164, 94);
            this.tb_prenom.Name = "tb_prenom";
            this.tb_prenom.Size = new System.Drawing.Size(135, 20);
            this.tb_prenom.TabIndex = 2;
            // 
            // tb_adresse_pro
            // 
            this.tb_adresse_pro.Location = new System.Drawing.Point(164, 134);
            this.tb_adresse_pro.Name = "tb_adresse_pro";
            this.tb_adresse_pro.Size = new System.Drawing.Size(135, 20);
            this.tb_adresse_pro.TabIndex = 2;
            // 
            // tb_tel_fixe
            // 
            this.tb_tel_fixe.Location = new System.Drawing.Point(164, 214);
            this.tb_tel_fixe.Name = "tb_tel_fixe";
            this.tb_tel_fixe.Size = new System.Drawing.Size(135, 20);
            this.tb_tel_fixe.TabIndex = 2;
            // 
            // tb_tel_mobile
            // 
            this.tb_tel_mobile.Location = new System.Drawing.Point(164, 254);
            this.tb_tel_mobile.Name = "tb_tel_mobile";
            this.tb_tel_mobile.Size = new System.Drawing.Size(135, 20);
            this.tb_tel_mobile.TabIndex = 2;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(164, 294);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(135, 20);
            this.tb_email.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(93, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 17);
            this.label9.TabIndex = 1;
            this.label9.Text = "Ville";
            // 
            // cbb_ville_pro
            // 
            this.cbb_ville_pro.FormattingEnabled = true;
            this.cbb_ville_pro.Location = new System.Drawing.Point(164, 174);
            this.cbb_ville_pro.Name = "cbb_ville_pro";
            this.cbb_ville_pro.Size = new System.Drawing.Size(135, 22);
            this.cbb_ville_pro.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(333, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 17);
            this.label10.TabIndex = 1;
            this.label10.Text = "Surface habitable";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.Location = new System.Drawing.Point(333, 94);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Surface parcelle";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.Location = new System.Drawing.Point(333, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "Type d\'habitation";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.Location = new System.Drawing.Point(333, 174);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 17);
            this.label13.TabIndex = 1;
            this.label13.Text = "Avec garage";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label14.Location = new System.Drawing.Point(482, 174);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 17);
            this.label14.TabIndex = 1;
            this.label14.Text = "Avec cave";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label15.Location = new System.Drawing.Point(333, 254);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(113, 17);
            this.label15.TabIndex = 1;
            this.label15.Text = "Adresse du bien";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label16.Location = new System.Drawing.Point(333, 294);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(134, 17);
            this.label16.TabIndex = 1;
            this.label16.Text = "Date mise en vente";
            // 
            // tb_surfacehabitable
            // 
            this.tb_surfacehabitable.Location = new System.Drawing.Point(460, 54);
            this.tb_surfacehabitable.Name = "tb_surfacehabitable";
            this.tb_surfacehabitable.Size = new System.Drawing.Size(113, 20);
            this.tb_surfacehabitable.TabIndex = 2;
            // 
            // tb_surfaceparcelle
            // 
            this.tb_surfaceparcelle.Location = new System.Drawing.Point(460, 94);
            this.tb_surfaceparcelle.Name = "tb_surfaceparcelle";
            this.tb_surfaceparcelle.Size = new System.Drawing.Size(113, 20);
            this.tb_surfaceparcelle.TabIndex = 2;
            // 
            // tb_adresse_bien
            // 
            this.tb_adresse_bien.Location = new System.Drawing.Point(460, 254);
            this.tb_adresse_bien.Name = "tb_adresse_bien";
            this.tb_adresse_bien.Size = new System.Drawing.Size(118, 20);
            this.tb_adresse_bien.TabIndex = 2;
            // 
            // cbb_type_habitation
            // 
            this.cbb_type_habitation.FormattingEnabled = true;
            this.cbb_type_habitation.Location = new System.Drawing.Point(460, 134);
            this.cbb_type_habitation.Name = "cbb_type_habitation";
            this.cbb_type_habitation.Size = new System.Drawing.Size(113, 22);
            this.cbb_type_habitation.TabIndex = 5;
            // 
            // checkBox_cave
            // 
            this.checkBox_cave.AutoSize = true;
            this.checkBox_cave.Location = new System.Drawing.Point(563, 174);
            this.checkBox_cave.Name = "checkBox_cave";
            this.checkBox_cave.Size = new System.Drawing.Size(15, 14);
            this.checkBox_cave.TabIndex = 6;
            this.checkBox_cave.UseVisualStyleBackColor = true;
            // 
            // checkBox_garage
            // 
            this.checkBox_garage.AutoSize = true;
            this.checkBox_garage.Location = new System.Drawing.Point(428, 174);
            this.checkBox_garage.Name = "checkBox_garage";
            this.checkBox_garage.Size = new System.Drawing.Size(15, 14);
            this.checkBox_garage.TabIndex = 6;
            this.checkBox_garage.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label17.Location = new System.Drawing.Point(603, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(142, 17);
            this.label17.TabIndex = 1;
            this.label17.Text = "Nombre de chambre";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label18.Location = new System.Drawing.Point(603, 94);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(153, 17);
            this.label18.TabIndex = 1;
            this.label18.Text = "Nombre salle de bains";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label19.Location = new System.Drawing.Point(603, 134);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(124, 17);
            this.label19.TabIndex = 1;
            this.label19.Text = "Nombre salle Eau";
            // 
            // numericUpDown_chambre
            // 
            this.numericUpDown_chambre.Location = new System.Drawing.Point(762, 54);
            this.numericUpDown_chambre.Name = "numericUpDown_chambre";
            this.numericUpDown_chambre.Size = new System.Drawing.Size(63, 20);
            this.numericUpDown_chambre.TabIndex = 7;
            // 
            // numericUpDown_bains
            // 
            this.numericUpDown_bains.Location = new System.Drawing.Point(762, 94);
            this.numericUpDown_bains.Name = "numericUpDown_bains";
            this.numericUpDown_bains.Size = new System.Drawing.Size(63, 20);
            this.numericUpDown_bains.TabIndex = 7;
            // 
            // numericUpDown_Eau
            // 
            this.numericUpDown_Eau.Location = new System.Drawing.Point(762, 134);
            this.numericUpDown_Eau.Name = "numericUpDown_Eau";
            this.numericUpDown_Eau.Size = new System.Drawing.Size(63, 20);
            this.numericUpDown_Eau.TabIndex = 7;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label20.Location = new System.Drawing.Point(603, 174);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(127, 17);
            this.label20.TabIndex = 1;
            this.label20.Text = "Nombre de pièces";
            // 
            // numericUpDown_pieces
            // 
            this.numericUpDown_pieces.Location = new System.Drawing.Point(762, 174);
            this.numericUpDown_pieces.Name = "numericUpDown_pieces";
            this.numericUpDown_pieces.Size = new System.Drawing.Size(63, 20);
            this.numericUpDown_pieces.TabIndex = 7;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label21.Location = new System.Drawing.Point(333, 214);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(116, 17);
            this.label21.TabIndex = 1;
            this.label21.Text = "Complémentaire";
            // 
            // tb_complementaire
            // 
            this.tb_complementaire.Location = new System.Drawing.Point(460, 214);
            this.tb_complementaire.Name = "tb_complementaire";
            this.tb_complementaire.Size = new System.Drawing.Size(365, 20);
            this.tb_complementaire.TabIndex = 2;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label22.Location = new System.Drawing.Point(615, 254);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 17);
            this.label22.TabIndex = 1;
            this.label22.Text = "Quartier";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label23.Location = new System.Drawing.Point(615, 294);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(34, 17);
            this.label23.TabIndex = 1;
            this.label23.Text = "Ville";
            // 
            // tb_quartier
            // 
            this.tb_quartier.Location = new System.Drawing.Point(682, 254);
            this.tb_quartier.Name = "tb_quartier";
            this.tb_quartier.Size = new System.Drawing.Size(141, 20);
            this.tb_quartier.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label24.Location = new System.Drawing.Point(333, 334);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(92, 17);
            this.label24.TabIndex = 1;
            this.label24.Text = "Prix souhaité";
            // 
            // tb_prix_souhait
            // 
            this.tb_prix_souhait.Location = new System.Drawing.Point(460, 334);
            this.tb_prix_souhait.Name = "tb_prix_souhait";
            this.tb_prix_souhait.Size = new System.Drawing.Size(113, 20);
            this.tb_prix_souhait.TabIndex = 2;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label25.Location = new System.Drawing.Point(615, 334);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(72, 17);
            this.label25.TabIndex = 1;
            this.label25.Text = "Prix vente";
            this.label25.Visible = false;
            // 
            // tb_prix_vente
            // 
            this.tb_prix_vente.Location = new System.Drawing.Point(698, 334);
            this.tb_prix_vente.Name = "tb_prix_vente";
            this.tb_prix_vente.Size = new System.Drawing.Size(125, 20);
            this.tb_prix_vente.TabIndex = 2;
            this.tb_prix_vente.Visible = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label26.Location = new System.Drawing.Point(333, 374);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(117, 17);
            this.label26.TabIndex = 1;
            this.label26.Text = "Date vente réelle";
            this.label26.Visible = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label27.Location = new System.Drawing.Point(615, 374);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(66, 17);
            this.label27.TabIndex = 1;
            this.label27.Text = "Acheteur";
            this.label27.Visible = false;
            // 
            // tb_acheteur
            // 
            this.tb_acheteur.Location = new System.Drawing.Point(687, 371);
            this.tb_acheteur.Name = "tb_acheteur";
            this.tb_acheteur.Size = new System.Drawing.Size(136, 20);
            this.tb_acheteur.TabIndex = 2;
            this.tb_acheteur.Visible = false;
            // 
            // cbb_ville_bien
            // 
            this.cbb_ville_bien.FormattingEnabled = true;
            this.cbb_ville_bien.Location = new System.Drawing.Point(683, 294);
            this.cbb_ville_bien.Name = "cbb_ville_bien";
            this.cbb_ville_bien.Size = new System.Drawing.Size(140, 22);
            this.cbb_ville_bien.TabIndex = 5;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label28.Location = new System.Drawing.Point(81, 356);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(46, 17);
            this.label28.TabIndex = 1;
            this.label28.Text = "Statut";
            // 
            // tb_statut
            // 
            this.tb_statut.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tb_statut.Location = new System.Drawing.Point(156, 349);
            this.tb_statut.Name = "tb_statut";
            this.tb_statut.ReadOnly = true;
            this.tb_statut.Size = new System.Drawing.Size(136, 26);
            this.tb_statut.TabIndex = 2;
            this.tb_statut.Text = "DISPONIBLE";
            // 
            // bt_save
            // 
            this.bt_save.Location = new System.Drawing.Point(232, 413);
            this.bt_save.Name = "bt_save";
            this.bt_save.Size = new System.Drawing.Size(142, 41);
            this.bt_save.TabIndex = 8;
            this.bt_save.Text = "CONTRAT";
            this.bt_save.UseVisualStyleBackColor = true;
            this.bt_save.Click += new System.EventHandler(this.butSave_Click);
            // 
            // bt_annuler
            // 
            this.bt_annuler.Location = new System.Drawing.Point(431, 413);
            this.bt_annuler.Name = "bt_annuler";
            this.bt_annuler.Size = new System.Drawing.Size(142, 41);
            this.bt_annuler.TabIndex = 8;
            this.bt_annuler.Text = "ANNULER";
            this.bt_annuler.UseVisualStyleBackColor = true;
            this.bt_annuler.Click += new System.EventHandler(this.bt_annuler_Click);
            // 
            // dateTimePicker_reel
            // 
            this.dateTimePicker_reel.Location = new System.Drawing.Point(473, 374);
            this.dateTimePicker_reel.Name = "dateTimePicker_reel";
            this.dateTimePicker_reel.Size = new System.Drawing.Size(105, 20);
            this.dateTimePicker_reel.TabIndex = 4;
            this.dateTimePicker_reel.Visible = false;
            // 
            // dateTimePicker_veut
            // 
            this.dateTimePicker_veut.Location = new System.Drawing.Point(473, 296);
            this.dateTimePicker_veut.Name = "dateTimePicker_veut";
            this.dateTimePicker_veut.Size = new System.Drawing.Size(105, 20);
            this.dateTimePicker_veut.TabIndex = 4;
            // 
            // Nouvelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bt_annuler);
            this.Controls.Add(this.bt_save);
            this.Controls.Add(this.numericUpDown_pieces);
            this.Controls.Add(this.numericUpDown_Eau);
            this.Controls.Add(this.numericUpDown_bains);
            this.Controls.Add(this.numericUpDown_chambre);
            this.Controls.Add(this.checkBox_garage);
            this.Controls.Add(this.checkBox_cave);
            this.Controls.Add(this.cbb_ville_bien);
            this.Controls.Add(this.cbb_type_habitation);
            this.Controls.Add(this.dateTimePicker_veut);
            this.Controls.Add(this.dateTimePicker_reel);
            this.Controls.Add(this.cbb_ville_pro);
            this.Controls.Add(this.tb_email);
            this.Controls.Add(this.tb_tel_mobile);
            this.Controls.Add(this.tb_complementaire);
            this.Controls.Add(this.tb_tel_fixe);
            this.Controls.Add(this.tb_adresse_pro);
            this.Controls.Add(this.tb_prenom);
            this.Controls.Add(this.tb_quartier);
            this.Controls.Add(this.tb_adresse_bien);
            this.Controls.Add(this.tb_surfaceparcelle);
            this.Controls.Add(this.tb_statut);
            this.Controls.Add(this.tb_acheteur);
            this.Controls.Add(this.tb_prix_vente);
            this.Controls.Add(this.tb_prix_souhait);
            this.Controls.Add(this.tb_surfacehabitable);
            this.Controls.Add(this.tb_nom);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Nouvelle";
            this.Size = new System.Drawing.Size(851, 540);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_chambre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_bains)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Eau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pieces)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_nom;
        private System.Windows.Forms.TextBox tb_prenom;
        private System.Windows.Forms.TextBox tb_adresse_pro;
        private System.Windows.Forms.TextBox tb_tel_fixe;
        private System.Windows.Forms.TextBox tb_tel_mobile;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbb_ville_pro;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tb_surfacehabitable;
        private System.Windows.Forms.TextBox tb_surfaceparcelle;
        private System.Windows.Forms.TextBox tb_adresse_bien;
        private System.Windows.Forms.ComboBox cbb_type_habitation;
        private System.Windows.Forms.CheckBox checkBox_cave;
        private System.Windows.Forms.CheckBox checkBox_garage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown numericUpDown_chambre;
        private System.Windows.Forms.NumericUpDown numericUpDown_bains;
        private System.Windows.Forms.NumericUpDown numericUpDown_Eau;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown numericUpDown_pieces;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tb_complementaire;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tb_quartier;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tb_prix_souhait;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tb_prix_vente;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tb_acheteur;
        private System.Windows.Forms.ComboBox cbb_ville_bien;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tb_statut;
        private System.Windows.Forms.Button bt_save;
        private System.Windows.Forms.Button bt_annuler;
        private System.Windows.Forms.DateTimePicker dateTimePicker_reel;
        private System.Windows.Forms.DateTimePicker dateTimePicker_veut;
    }
}
