﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Immo_Rale.ShowForm.Biens;
using Immo_Rale.Management;

namespace Immo_Rale.ShowForm
{
    public partial class MainPage : Form
    {
        private UserControl current;
        private static TabControl tabControl;
       
        public MainPage()
        {
            InitializeComponent();
            tabControl = tabControl_Biens;
            changeTab(tabPage1_Biens, new Nouvelle());
        }
        private void changeTab(TabPage tab, UserControl uc)
        {
            uc.Size = tab.Size;
            tab.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            tab.Controls.Add(uc);
        }

        private void tabControl_Biens_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl_Biens.SelectedTab == tabPage1_Biens)
            {
                changeTab(tabPage1_Biens, new Nouvelle());
            }
            else if (tabControl_Biens.SelectedTab == tabPage2_Biens)
            {
                Liste_bien uc = new Liste_bien();
                uc.BiensSelected += (s2, e1) =>
                {
                    tabControl.SelectedTab = tabPage1_Biens;
                    changeTab(tabPage1_Biens, new Nouvelle((Immo_Rale.Management.Biens)s2));
                };
                changeTab(tabPage2_Biens, uc);
            }
        }

    }
}
