﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntrepriseManagement_v1.View.Project
{
    public partial class AddEditProject : UserControl
    {
        public AddEditProject()
        {
            InitializeComponent();
        }
    }
}
