﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntrepriseManagement_v1.View.Employee;
using EntrepriseManagement_v1.View.Project;
using EntrepriseManagement_v1.Entity;

namespace EntrepriseManagement_v1.View
{
    public partial class Main : Form
    {
        private UserControl current;
        private static TabControl tabControl;

        public Main()
        {
            InitializeComponent();
            tabControl = tabControl1;

            changeTab(tabPage1, new AddEditEmployee());
        }

        private void changeTab(TabPage tab, UserControl uc)
        {
            uc.Size = tab.Size;
            tab.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            tab.Controls.Add(uc);
            

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabPage1)
            {
                changeTab(tabPage1, new AddEditEmployee());
            }
            else if (tabControl1.SelectedTab == tabPage2)
            {
                changeTab(tabPage2, new AddEditProject());
            }
            else if (tabControl1.SelectedTab == tabPage3)
            {
                ShowEmployee uc = new ShowEmployee();
                uc.EmployeeSelected += (s1, e1) =>
                    {
                        tabControl.SelectedTab = tabPage1;
                        changeTab(tabPage1, new AddEditEmployee((EntrepriseManagement_v1.Entity.Employee)s1));
                        
                    };
                changeTab(tabPage3, uc);
            }
        }

    }
}
