﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntrepriseManagement_v1.Configuration
{
    public class Config
    {
        public static string DB_PATH = ".\\Database\\entreprise.db";
        public static String[] ALL_ROLES = { "Thợ chính", "Thợ phụ" };
    }
}
