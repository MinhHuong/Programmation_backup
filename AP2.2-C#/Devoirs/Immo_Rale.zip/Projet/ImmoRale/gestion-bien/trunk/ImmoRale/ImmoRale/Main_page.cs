﻿using ImmoRale.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImmoRale
{
    public partial class Main_page : Form
    {
        //private UserControl current;
        private static TabControl tabControl;
        private Guid id = Guid.Empty;
        private string firstName;
        private string lastName;
        private string address;
        private string mobile;
        private int wage;
        private string cmnd;
        private string mst;
        private string role;
        public static string DB_PATH = "C:\\Users\\Sa Doa Tien Sinh\\Desktop\\Gestion-Projet\\Projet\\ImmoRale\\gestion-bien\\trunk\\ImmoRale\\ImmoRale\\Database\\mydatabase.sqlite";

        public Main_page()
        {
            InitializeComponent();
            //tabControl = tabControl1;


            //DB.DbManager.getFirst()
        }
        //private void changeTab(TabPage tab, UserControl uc)
        //{
        //    current = uc;
        //    current.Size = tab.Size;
        //    tab.Controls.Add(current);
        //}
        public static Int16 parseInt(string num)
        {
            Int16 res;
            if (Int16.TryParse(num, out res))
                return res;
            else
                return 0;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SQLiteDatabase database = new SQLiteDatabase("C:\\Users\\Sa Doa Tien Sinh\\Desktop\\Gestion-Projet\\Projet\\ImmoRale\\gestion-bien\\trunk\\ImmoRale\\ImmoRale\\Database\\mydatabase.sqlite");
            //SQLiteCommand create = database.GetCommand("CREATE TABLE Customers (Id int PRIMARY KEY, Name nvarchar(256), Address nvarchar(256), PostCode nvarchar(256))");
            //database.ExecuteNonQuery(create); 
            //SQLiteCommand populate = database.GetCommand("INSERT INTO Customers ('Id', 'Name', 'Address', 'PostCode') VALUES (1, 'Jon Preece', 'My House', 'NN11NN')");
            //int affected = database.ExecuteNonQuery(populate);
            SQLiteCommand a = database.GetCommand("SELECT * FROM BIENS where rowid = 2");
            DataTable res = database.GetDataTable(a);
            DataTable data = new DataTable();;
            
            
            ////const string filename = @"C:\cplus\tutorials\c#\SQLite\About.sqlite";
            //const string sql = "select * from BIENS;";
            ////MessageBox.Show(" hic hic ");
            //var conn = new SQLiteConnection("Data Source=" + DB_PATH + ";Version=3;");
            //try
            //{
            //    conn.Open();
            //    DataSet ds = new DataSet();
            //    var da = new SQLiteDataAdapter(sql, conn);
            ////    MessageBox.Show( da.ToString());
            //    da.Fill(data);MessageBox.Show( ds.ToString());
            //    dataGridView1.DataSource = data;
            //}
            //catch (Exception)
            //{
            //    throw;
            //}


            Dictionary<string, object> dict = DbManager.getFirst(DB_PATH, "BIENS", "");
            //id = Guid.Parse((String)dict["id"]);
               firstName = (String)dict["statusbien"];
               // lastName = (String)dict["lastname"];
               // address = (String)dict["address"];
               // mobile = (String)dict["mobile"];
               // wage = parseInt(dict["wage"].ToString());
               // cmnd = (String)dict["cmnd"];
               // mst = (String)dict["mst"];
                //role = (String)dict["role"];
            MessageBox.Show(firstName);
            dataGridView1.DataSource = res;
            ShowForm.Form1 hehe = new ShowForm.Form1();
            hehe.Show();
            //if (tabControl1.SelectedTab == tabPage1)
            //{
             //   var temp = DbManager.getList(DB_PATH, "BIENS", "");
            //    dataGridView1.DataSource = temp;
            //}
            //else if (tabControl1.SelectedTab == tabPage2)
            //{
            //    //changeTab(tabPage2, new ShowEmployee());
           // } 
        }
       /* private static Employee createEntityFrom(Dictionary<string, object> dict)
        

        private String[] getValues()
        {
            return new String[] { "'" + Id.ToString() + "'", "'" + FirstName + "'", "'" + LastName + "'", "'" + Address + "'"
                , "'" + Mobile + "'", Wage.ToString(), "'" + CMND + "'", "'" + MST + "'", "'" + Role + "'" };
        }


        public static List<Employee> getList(string where)
        {
            List<Employee> res = null;

            var temp = DbManager.getList(Configuration.Config.DB_PATH, TABLE_NAME, where);
            if (temp != null)
            {
                res = new List<Employee>();

                foreach (Dictionary<string, object> entry in temp)
                {
                    res.Add(createEntityFrom(entry));
                }
            }

            return res;
            dataGridView1.DataSource = lsObj;
        }*/

    }
}
