﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImmoRale.ShowForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Visible = false;
            this.tabControl2.Visible = false;
            this.tabControl3.Visible = false;
            this.tabControl4.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tabControl1.Visible = false;
            this.tabControl2.Visible = false;
            this.tabControl3.Visible = true;
            this.tabControl4.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.tabControl1.Visible = false;
            this.tabControl2.Visible = true;
            this.tabControl3.Visible = false;
            this.tabControl4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.tabControl1.Visible = true;
            this.tabControl2.Visible = false;
            this.tabControl3.Visible = false;
            this.tabControl4.Visible = false;
        }


    }
}
