﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Windows.Forms;

namespace DessinObjets
{
    public partial class DessinObjets : Form
    {
#region attributs
        private bool enDeplacement = false;
        private bool enDessin = false;

        private List<Noeud> noeuds = new List<Noeud>();
        private Noeud noeudCourant = null;
        private Point pointCourant = Point.Empty;
        private List<Trait> traits = new List<Trait>();

        private Size tailleDefaut = new Size(10, 10);
        private Color couleurDefaut = Color.Black;
        private int epaisseurDefaut = 1;
#endregion

        public DessinObjets()
        {
            InitializeComponent();
            MoinsEpaisseur.Enabled = false;
        }

        private Noeud NoeudDefaut(Point p)
        {
            return new Noeud(p, tailleDefaut, couleurDefaut, epaisseurDefaut);
        }

        private Noeud TrouveNoeud(Point p)
        {
            foreach (Noeud n in noeuds)
            {
                if (n.Contains(p))
                {
                    return n;
                }
            }

            return null;
        }

        private Trait TrouveTrait(Noeud n)
        {
            foreach (Trait t in traits)
            {
                if (n == t.Extremite_Dest || n == t.Extremite_Source)
                {
                    return t;
                }
            }

            return null;
        }

        private void DessinObjets_MouseDown(object sender, MouseEventArgs e)
        {
            noeudCourant = TrouveNoeud(e.Location);

            switch (e.Button)
            {
                case System.Windows.Forms.MouseButtons.Left:
                    #region ButtonLeft
                    {
                        if (deplacement.Checked)
                        {
                            if (noeudCourant != null)
                            {
                                enDeplacement = true;
                            }
                        }
                        else
                        {
                            if (noeudCourant == null)
                            {
                                noeuds.Add(NoeudDefaut(e.Location));
                                Refresh();
                            }
                            else
                            {
                                enDessin = true;
                            }
                        }
                #endregion
                        break;
                    }

                case System.Windows.Forms.MouseButtons.Right:
                    #region ButtonRight
                    {
                        string[] libelles = new string[] { "Supprimer", "Modifier" };
                        ContextMenuStrip cm = new ContextMenuStrip();

                        foreach (string libel in libelles)
                        {
                            ToolStripMenuItem menuItem = new ToolStripMenuItem(libel);
                            menuItem.Click += menuItem_Click;
                            cm.Items.Add(menuItem);
                        }

                        cm.Show(this, e.Location);
                    #endregion
                        break;
                    }
            }
        }
    
        private void menuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tm = (ToolStripMenuItem)sender;
            switch (tm.Text)
            {
                case "Modifier":
                    {
                        #region Modifier
                        if (noeudCourant != null)
                    {
                        Parametres param = new Parametres();

                        param.Param_Couleur = noeudCourant.Couleur;
                        param.Param_Epaisseur = noeudCourant.Epaisseur;
                        param.Param_Police = noeudCourant.Font_Texte;
                        param.Param_Texte = noeudCourant.Text;

                        if (param.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            noeudCourant.Epaisseur = param.Param_Epaisseur;
                            noeudCourant.Couleur = param.Param_Couleur;
                            noeudCourant.Font_Texte = param.Param_Police;
                            noeudCourant.Text = param.Param_Texte;

                            Refresh();
                        }
                    }
                        #endregion
                        break;
                    }

                case "Supprimer":
                    {
                        #region Supprimer
                        
                        if (noeudCourant != null )
                        { 
                            while( TrouveTrait(noeudCourant)!=null )
                            {
                                traits.Remove(TrouveTrait(noeudCourant));
                            }
                            noeuds.Remove(noeudCourant);
                            Refresh();
                        }
                        #endregion
                        break;
                }   
            }
        }

        private void DessinObjets_Paint(object sender, PaintEventArgs e)
        {
            foreach (Noeud n in noeuds)
                n.Dessine(e.Graphics);

            foreach (Trait t in traits)
                t.Dessine(e.Graphics);

            if (pointCourant != Point.Empty)
            {
                Noeud fin = NoeudDefaut(pointCourant);
                fin.Dessine(e.Graphics);
                e.Graphics.DrawLine(Pens.Red, noeudCourant.Centre, pointCourant);
            }
        }

        private void DessinObjets_MouseMove(object sender, MouseEventArgs e)
        {
            if (enDeplacement)
            {
                noeudCourant.Move(e.Location);
            }

            if (enDessin)
            {
                pointCourant = e.Location;
            }

            Refresh();
        }

        private void DessinObjets_MouseUp(object sender, MouseEventArgs e)
        {
            if (enDessin)
            {
                Noeud trouve = TrouveNoeud(e.Location);

                if( trouve==null)
                {
                    trouve = NoeudDefaut(e.Location);
                    noeuds.Add(trouve);
                }

                Trait trait = new Trait(noeudCourant, trouve, Color.Red,1);
                traits.Add(trait);
                Refresh();
            }

            enDeplacement = false;
            enDessin = false;
            pointCourant = Point.Empty;
        }

        private void Plus_Click(object sender, EventArgs e)
        {
            if (epaisseurDefaut < 10)
            {
                epaisseurDefaut++;
                MoinsEpaisseur.Enabled = true;
            }
            else
            {
                PlusEpaisseur.Enabled = false;
                MessageBox.Show("Epaisseur maximal");
            }

        }

        private void Moins_Click(object sender, EventArgs e)
        {
            if (epaisseurDefaut > 1)
            {
                epaisseurDefaut--;
                PlusEpaisseur.Enabled = true;
            }
            else
            {
                MoinsEpaisseur.Enabled = false;
                MessageBox.Show("Epaisseur minimal");   
            }
        }

        private void couleurDefaut_Click(object sender, EventArgs e)
        {
            ColorDialog c = new ColorDialog();
            c.Color = couleurDefaut;
            if (c.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                couleurDefaut = c.Color;
            }
        }

        private void NewButton_Click(object sender, EventArgs e)
        {
            noeuds.Clear();
            traits.Clear();
            Refresh();
        }

        // Sauvegarder & lire des fichiers CSV
        /*
        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog svfd = new SaveFileDialog();
            svfd.Filter = "Fichier csv|*.csv";
            svfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (svfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(svfd.FileName);

                sw.WriteLine(noeuds.Count.ToString());
                foreach (Noeud noeud in noeuds)
                {
                    sw.Write(noeud.ToString());
                    sw.WriteLine();
                }

                sw.WriteLine(traits.Count.ToString());
                foreach (Trait trait in traits)
                {
                    sw.Write(trait.ToString());
                    sw.WriteLine();
                }

                sw.Close();
            }
        }

        private void OpenButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog opfd = new OpenFileDialog();
            opfd.Filter = "Fichier csv|*.csv";
            opfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (opfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                noeuds.Clear();
                traits.Clear();
                StreamReader sr = new StreamReader(opfd.FileName);
                string champ;

                // lecture des noeuds
                int nb_noeuds = int.Parse(sr.ReadLine());
                for( int i = 0 ; i < nb_noeuds && !sr.EndOfStream ; i++ )
                {
                    champ = sr.ReadLine();
                    Noeud n = new Noeud(champ);
                    noeuds.Add(n);
                }

                // lecture des traits
                int nb_traits = int.Parse(sr.ReadLine());
                for (int i = 0; i < nb_traits && !sr.EndOfStream ; i++)
                {
                    champ = sr.ReadLine();
                    Trait t = new Trait(champ, noeuds);

                    traits.Add(t);
                }

                sr.Close();
                Refresh();
            }
        }
        */

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog save_dia = new SaveFileDialog();
            save_dia.Filter = "Fichier XML|*.xml";
            if (save_dia.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(save_dia.FileName);
                sw.WriteLine("<!--?xml version=\"1.0\" encoding=\"UTF-8\" ?--> ");
                sw.WriteLine("<DESSIN>");

                foreach (Noeud n in noeuds)
                {
                    sw.WriteLine(n.ToXML());
                }

                foreach (Trait t in traits)
                {
                    sw.WriteLine(t.ToXML());
                }

                sw.WriteLine("</DESSIN>");
                sw.Close();
            }

        }

        private void OpenButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog op_dia = new OpenFileDialog();
            op_dia.Filter = "Fichier XML | *.xml";

            if (op_dia.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                noeuds.Clear();
                traits.Clear();

                XmlDocument doc = new XmlDocument();
                doc.Load(op_dia.FileName);

                foreach (XmlNode xN in doc.ChildNodes)
                {
                    if (xN.Name == "DESSIN")
                    {
                        foreach (XmlNode xNN in xN.ChildNodes)
                        {
                            if (xNN.Name == "NOEUD")
                            {
                                Noeud n = new Noeud(xNN);
                                noeuds.Add(n);
                            }
                            else if (xNN.Name == "TRAIT")
                            {
                                Trait t = new Trait(xNN, noeuds);
                                traits.Add(t);
                            }
                        }
                    }
                }

                Refresh();
            }
        }
        
    }
}
