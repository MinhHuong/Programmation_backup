﻿namespace DessinObjets
{
    partial class Parametres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Texte = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Epaisseur = new System.Windows.Forms.Label();
            this.numericUpDownEpaisseur = new System.Windows.Forms.NumericUpDown();
            this.Couleur = new System.Windows.Forms.Label();
            this.OK = new System.Windows.Forms.Button();
            this.Annuler = new System.Windows.Forms.Button();
            this.LabelCouleur = new System.Windows.Forms.Label();
            this.Police = new System.Windows.Forms.Label();
            this.TextFont = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEpaisseur)).BeginInit();
            this.SuspendLayout();
            // 
            // Texte
            // 
            this.Texte.AutoSize = true;
            this.Texte.Location = new System.Drawing.Point(30, 50);
            this.Texte.Name = "Texte";
            this.Texte.Size = new System.Drawing.Size(43, 17);
            this.Texte.TabIndex = 0;
            this.Texte.Text = "Texte";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(130, 50);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 1;
            // 
            // Epaisseur
            // 
            this.Epaisseur.AutoSize = true;
            this.Epaisseur.Location = new System.Drawing.Point(30, 100);
            this.Epaisseur.Name = "Epaisseur";
            this.Epaisseur.Size = new System.Drawing.Size(71, 17);
            this.Epaisseur.TabIndex = 2;
            this.Epaisseur.Text = "Epaisseur";
            // 
            // numericUpDownEpaisseur
            // 
            this.numericUpDownEpaisseur.Location = new System.Drawing.Point(130, 100);
            this.numericUpDownEpaisseur.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownEpaisseur.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownEpaisseur.Name = "numericUpDownEpaisseur";
            this.numericUpDownEpaisseur.Size = new System.Drawing.Size(100, 22);
            this.numericUpDownEpaisseur.TabIndex = 3;
            this.numericUpDownEpaisseur.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownEpaisseur.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Couleur
            // 
            this.Couleur.AutoSize = true;
            this.Couleur.Location = new System.Drawing.Point(30, 150);
            this.Couleur.Name = "Couleur";
            this.Couleur.Size = new System.Drawing.Size(57, 17);
            this.Couleur.TabIndex = 4;
            this.Couleur.Text = "Couleur";
            // 
            // OK
            // 
            this.OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OK.Location = new System.Drawing.Point(320, 67);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(110, 35);
            this.OK.TabIndex = 5;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            // 
            // Annuler
            // 
            this.Annuler.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Annuler.Location = new System.Drawing.Point(320, 142);
            this.Annuler.Name = "Annuler";
            this.Annuler.Size = new System.Drawing.Size(110, 35);
            this.Annuler.TabIndex = 6;
            this.Annuler.Text = "Annuler";
            this.Annuler.UseVisualStyleBackColor = true;
            // 
            // LabelCouleur
            // 
            this.LabelCouleur.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelCouleur.Location = new System.Drawing.Point(130, 150);
            this.LabelCouleur.Name = "LabelCouleur";
            this.LabelCouleur.Size = new System.Drawing.Size(100, 22);
            this.LabelCouleur.TabIndex = 7;
            this.LabelCouleur.Click += new System.EventHandler(this.labelCouleur_Click);
            // 
            // Police
            // 
            this.Police.AutoSize = true;
            this.Police.Location = new System.Drawing.Point(30, 200);
            this.Police.Name = "Police";
            this.Police.Size = new System.Drawing.Size(46, 17);
            this.Police.TabIndex = 8;
            this.Police.Text = "Police";
            // 
            // TextFont
            // 
            this.TextFont.AutoSize = true;
            this.TextFont.Location = new System.Drawing.Point(130, 200);
            this.TextFont.Name = "TextFont";
            this.TextFont.Size = new System.Drawing.Size(43, 17);
            this.TextFont.TabIndex = 9;
            this.TextFont.Text = "Texte";
            this.TextFont.Click += new System.EventHandler(this.TextFont_Click);
            // 
            // Parametres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 262);
            this.Controls.Add(this.TextFont);
            this.Controls.Add(this.Police);
            this.Controls.Add(this.LabelCouleur);
            this.Controls.Add(this.Annuler);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.Couleur);
            this.Controls.Add(this.numericUpDownEpaisseur);
            this.Controls.Add(this.Epaisseur);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Texte);
            this.Name = "Parametres";
            this.Text = "Parametres";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEpaisseur)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Texte;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Epaisseur;
        private System.Windows.Forms.NumericUpDown numericUpDownEpaisseur;
        private System.Windows.Forms.Label Couleur;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Annuler;
        private System.Windows.Forms.Label LabelCouleur;
        private System.Windows.Forms.Label Police;
        private System.Windows.Forms.Label TextFont;
    }
}