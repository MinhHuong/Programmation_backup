﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DessinObjets
{
    public partial class Parametres : Form
    {
        public Color Param_Couleur
        {
            get { return LabelCouleur.BackColor; }
            set { LabelCouleur.BackColor = value; }
        }

        public int Param_Epaisseur
        {
            get { return (int)numericUpDownEpaisseur.Value; }
            set { numericUpDownEpaisseur.Value = value; }
        }

        public String Param_Texte
        {
            get { return textBox1.Text; }
            set { textBox1.Text = value; }
        }

        public Font Param_Police
        {
            get { return TextFont.Font; }
            set { TextFont.Font = value; }
        }

        public Parametres()
        {
            InitializeComponent();
        }

        private void labelCouleur_Click(object sender, EventArgs e)
        {
            ColorDialog c = new ColorDialog();
            c.Color = LabelCouleur.BackColor;
            if (c.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                LabelCouleur.BackColor = c.Color;
            }
        }

        private void TextFont_Click(object sender, EventArgs e)
        {
            FontDialog f = new FontDialog();
            f.Font = TextFont.Font;
            if (f.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                TextFont.Font = f.Font;
            }
        }

       
    }
}
