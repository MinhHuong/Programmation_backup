﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace DessinObjets
{
    class Noeud
    {
#region attributs
        private Rectangle rect;
        private Color couleur;
        private int epaisseur;
        private String texte;
        private Font texte_font;
#endregion attributs

#region propriete
        public int Epaisseur
        {
            get { return (int)epaisseur; }
            set { epaisseur = value; }
        }

        public Color Couleur
        {
            get { return couleur; }
            set { couleur = value; }
        }

        public String Text
        {
            get { return texte; }
            set { texte = value; }
        }

        public Font Font_Texte
        {
            get { return texte_font; }
            set { texte_font = value; }
        }

        public Point Centre
        {
            get { return new Point(rect.X + rect.Width / 2, rect.Y + rect.Height / 2); }
            set
            {
                rect.X = value.X - rect.Width / 2;
                rect.Y = value.Y - rect.Height / 2;
            }
        }

#endregion propriete

        // Constructeur
        public Noeud(Point p, Size s, Color c, int e)
        {
            rect = new Rectangle(new Point(p.X-s.Width/2, p.Y-s.Height/2), s);
            couleur = c;
            epaisseur = e;
        }

        public Noeud(string champ)
        {
            string[] donnees = champ.Split(';');

            // premiere valeur : l'epaisseur
            epaisseur = int.Parse(donnees[0]);

            // deuxieme valeur : la couleur
            couleur = Color.FromArgb(int.Parse(donnees[1]));

            // troisieme valeur : le rectangle
            char[] delimiters = new char[] { '=', ',' , '}' };
            string[] parts = donnees[2].Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
            rect = new Rectangle(int.Parse(parts[1]), int.Parse(parts[3]), int.Parse(parts[5]), int.Parse(parts[7]));
        }

        public Noeud(XmlNode xNN)
        {
            foreach (XmlNode xNNN in xNN.ChildNodes)
            {
                switch (xNNN.Name)
                {
                    case "epaisseur":
                        {
                            epaisseur = int.Parse(xNNN.InnerText);
                            break;
                        }

                    case "couleur":
                        {
                            int c = int.Parse(xNNN.InnerText);
                            couleur = Color.FromArgb(c);
                            break;
                        }

                    case "rectangle":
                        {
                            string[] data = xNNN.InnerText.Split(',');

                            int x = int.Parse(data[0].Split('=')[1]);
                            int y = int.Parse(data[1].Split('=')[1]);
                            int w = int.Parse(data[2].Split('=')[1]);
                            int h = int.Parse(data[3].Replace("}", "").Split('=')[1]);

                            rect = new Rectangle(x, y, w, h);

                            break;
                        }
                }
            }
        }

        // Methode dessine
        public void Dessine(Graphics g, float zoom, Point origin)
        {
            Pen p = new Pen(couleur, epaisseur);
            Rectangle r = new Rectangle((int)( (rect.X * zoom) + origin.X), 
                                        (int)( (rect.Y * zoom) + origin.Y),
                                        (int)(rect.Width * zoom), 
                                        (int)(rect.Height * zoom));

            g.DrawRectangle(p, r);
            g.DrawString(texte, texte_font, Brushes.Black, new Point(rect.X + rect.Width, rect.Y + rect.Height));
        }

        public bool Contains(Point p)
        {
            return rect.Contains(p);
        }

        public void Move(Point p)
        {
            rect.Location = new Point(p.X - rect.Width / 2, p.Y - rect.Height / 2);
        }

        public override string ToString()
        {
            string s = "";

            s += epaisseur.ToString();
            s += ";";

            s += couleur.ToArgb().ToString();
            s += ";";

            s += rect.ToString();

            return s;
        }

        public string ToXML()
        {
            string text = "<NOEUD>";

            text += "<epaisseur>";
            text += epaisseur.ToString();
            text += "</epaisseur>";

            text += "<couleur>";
            text += couleur.ToArgb().ToString();
            text += "</couleur>";

            text += "<rectangle>";
            text += rect.ToString();
            text += "</rectangle>";

            text += "</NOEUD>";

            return text;
        }

    }
}
