﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Xml;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace DessinObjets
{
    class Trait
    {
        private Noeud source;
        private Noeud destination;
        private Color couleur;
        private int epaisseur;

        public Noeud Extremite_Source
        {
            get { return source; }
            set { source = value; }
        }

        public Noeud Extremite_Dest
        {
            get { return destination; }
            set { destination = value; }
        }

        // Constructeur
        public Trait(Noeud src, Noeud dest, Color c, int e)
        {
            source = src;
            destination = dest;
            couleur = c;
            epaisseur = e;
        }

        public Trait(string champ, List<Noeud> noeuds)
        {
            string[] donnees = champ.Split(';');

            // premiere valeur : l'epaisseur
            epaisseur = int.Parse(donnees[0]);

            // deuxieme valeur : la couleur
            couleur = Color.FromArgb(int.Parse(donnees[1]));

            // troisieme valeur : Noeud source
            string noeud = donnees[2];
            noeud += ";";
            noeud += donnees[3];
            noeud += ";";
            noeud += donnees[4];

            Noeud test = new Noeud(noeud);

            foreach (Noeud n in noeuds)
            {
                if (n.Contains(test.Centre))
                {
                    source = n;
                }
            }

            // quatrieme valeur : Noeud destination
            noeud = donnees[5];
            noeud += ";";
            noeud += donnees[6];
            noeud += ";";
            noeud += donnees[7];

            test = new Noeud(noeud);

            foreach (Noeud n in noeuds)
            {
                if (n.Contains(test.Centre))
                {
                    destination = n;
                }
            }
        }

        public Trait(XmlNode xNN, List<Noeud> noeuds)
        {
            foreach (XmlNode xNNN in xNN.ChildNodes)
            {
                switch (xNNN.Name)
                {
                    case "epaisseur":
                        {
                            epaisseur = int.Parse(xNNN.InnerText);
                            break;
                        }

                    case "couleur":
                        {
                            int c = int.Parse(xNNN.InnerText);
                            couleur = Color.FromArgb(c);
                            break;
                        }

                    case "source":
                        {
                            XmlNode xNNNN = xNNN.FirstChild;
                            Noeud test = new Noeud(xNNNN);

                            foreach (Noeud n in noeuds)
                            {
                                if (n.Contains(test.Centre))
                                {
                                    source = n;
                                }
                            }

                            break;
                        }

                    case "destination":
                        {
                            XmlNode xNNNN = xNNN.FirstChild;
                            Noeud test = new Noeud(xNNNN);

                            foreach (Noeud n in noeuds)
                            {
                                if (n.Contains(test.Centre))
                                {
                                    destination = n;
                                }
                            }

                            break;
                        }
                }
            }
        }

        // Méthodes

        public void Dessine(Graphics g, float zoom, Point origin)
        {
            Pen p = new Pen(couleur, epaisseur);

            Point src = new Point( (int)(source.Centre.X * zoom + origin.X), (int) (source.Centre.Y * zoom + origin.Y));
            Point dest = new Point((int)(destination.Centre.X * zoom + origin.X), (int)(destination.Centre.Y * zoom + origin.Y));

            g.DrawLine(p, src, dest);
        }

        public override string ToString()
        {
            string s = "";

            s += epaisseur.ToString();
            s += ";";

            s += couleur.ToArgb().ToString();
            s += ";";

            s += source.ToString();
            s += ";";

            s += destination.ToString();

            return s;
        }

        public string ToXML()
        {
            string text = "<TRAIT>";

            text += "<epaisseur>";
            text += epaisseur.ToString();
            text += "</epaisseur>";

            text += "<couleur>";
            text += couleur.ToArgb().ToString();
            text += "</couleur>";

            text += "<source>";
            text += source.ToXML();
            text += "</source>";

            text += "<destination>";
            text += destination.ToXML();
            text += "</destination>";

            text += "</TRAIT>";

            return text;
        }
    }
}
