﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Windows.Forms;

namespace DessinObjets
{
    public partial class DessinObjets : Form
    {
#region attributs
        private bool enDeplacement = false;
        private bool enDessin = false;

        private List<Noeud> noeuds = new List<Noeud>();
        private Noeud noeudCourant = null;
        private Point pointCourant = Point.Empty;
        private List<Trait> traits = new List<Trait>();

        private Size tailleDefaut = new Size(10, 10);
        private Color couleurDefaut = Color.Black;
        private int epaisseurDefaut = 1;

        private VScrollBar vScroll = new VScrollBar();
        private HScrollBar hScroll = new HScrollBar();

        private Point origin = new Point(0, 0);
        private float zoom = 1;
#endregion

        public DessinObjets()
        {
            InitializeComponent();
            Init();
        }

        public void Init()
        {
            MoinsEpaisseur.Enabled = false;

            vScroll.Dock = DockStyle.Right;
            Controls.Add(vScroll);
            vScroll.Scroll += new ScrollEventHandler(this.vScroll_Scroll);
            vScroll.Minimum = 0;
            vScroll.Maximum = 300;
            vScroll.Value = 0;
            vScroll.SmallChange = 4;
            vScroll.LargeChange = 50;

            hScroll.Dock = DockStyle.Bottom;
            Controls.Add(hScroll);
            hScroll.Scroll += new ScrollEventHandler(this.hScroll_Scroll);
            hScroll.Minimum = 0;
            hScroll.Maximum = 300;
            hScroll.Value = 0;
            hScroll.SmallChange = 4;
            hScroll.LargeChange = 50;

            this.MouseWheel += DessinObjets_MouseWheel;
        }

        private Noeud NoeudDefaut(Point p)
        {
            return new Noeud(p, tailleDefaut, couleurDefaut, epaisseurDefaut);
        }

        private Noeud TrouveNoeud(Point p)
        {
            foreach (Noeud n in noeuds)
            {
                if (n.Contains(p))
                {
                    return n;
                }
            }

            return null;
        }

        private Trait TrouveTrait(Noeud n)
        {
            foreach (Trait t in traits)
            {
                if (n == t.Extremite_Dest || n == t.Extremite_Source)
                {
                    return t;
                }
            }

            return null;
        }

        private void DessinObjets_MouseDown(object sender, MouseEventArgs e)
        {
            noeudCourant = TrouveNoeud(new Point((int) ((e.Location.X - origin.X) / zoom), 
                                                 (int) ((e.Location.Y - origin.Y) / zoom)));

            switch (e.Button)
            {
                case System.Windows.Forms.MouseButtons.Left:
                    #region ButtonLeft
                    {
                        if (deplacement.Checked)
                        {
                            if (noeudCourant != null)
                            {
                                enDeplacement = true;
                            }
                        }
                        else
                        {
                            if (noeudCourant == null)
                            {
                                noeuds.Add(NoeudDefaut(new Point((int) ((e.Location.X - origin.X) / zoom), 
                                                                 (int) ((e.Location.Y - origin.Y) / zoom))));
                                Refresh();
                            }
                            else
                            {
                                enDessin = true;
                            }
                        }
                     #endregion
                        break;
                    }

                case System.Windows.Forms.MouseButtons.Right:
                    #region ButtonRight
                    {
                        string[] libelles = new string[] { "Supprimer", "Modifier" };
                        ContextMenuStrip cm = new ContextMenuStrip();

                        foreach (string libel in libelles)
                        {
                            ToolStripMenuItem menuItem = new ToolStripMenuItem(libel);
                            menuItem.Click += menuItem_Click;
                            cm.Items.Add(menuItem);
                        }

                        cm.Show(this, e.Location);
                    #endregion
                        break;
                    }
            }
        }
    
        private void menuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tm = (ToolStripMenuItem)sender;
            switch (tm.Text)
            {
                case "Modifier":
                    {
                        #region Modifier
                        if (noeudCourant != null)
                    {
                        Parametres param = new Parametres();

                        param.Param_Couleur = noeudCourant.Couleur;
                        param.Param_Epaisseur = noeudCourant.Epaisseur;
                        param.Param_Police = noeudCourant.Font_Texte;
                        param.Param_Texte = noeudCourant.Text;

                        if (param.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            noeudCourant.Epaisseur = param.Param_Epaisseur;
                            noeudCourant.Couleur = param.Param_Couleur;
                            noeudCourant.Font_Texte = param.Param_Police;
                            noeudCourant.Text = param.Param_Texte;

                            Refresh();
                        }
                    }
                        #endregion
                        break;
                    }

                case "Supprimer":
                    {
                        #region Supprimer
                        
                        if (noeudCourant != null )
                        { 
                            while( TrouveTrait(noeudCourant)!=null )
                            {
                                traits.Remove(TrouveTrait(noeudCourant));
                            }
                            noeuds.Remove(noeudCourant);
                            Refresh();
                        }
                        #endregion
                        break;
                }   
            }
        }

        private void DessinObjets_Paint(object sender, PaintEventArgs e)
        {
            foreach (Noeud n in noeuds)
                n.Dessine(e.Graphics, zoom, origin);

            foreach (Trait t in traits)
                t.Dessine(e.Graphics, zoom, origin);

            if (pointCourant != Point.Empty)
            {
                Noeud fin = NoeudDefaut(pointCourant);
                fin.Dessine(e.Graphics, zoom, origin);

                Point _pointCourant = new Point((int)(pointCourant.X * zoom) + origin.X,
                                                (int)(pointCourant.Y * zoom) + origin.Y);
                Point _noeudCourant = new Point((int)(noeudCourant.Centre.X * zoom) + origin.X,
                                                (int)(noeudCourant.Centre.Y * zoom) + origin.Y);
                
                e.Graphics.DrawLine(Pens.Red, _noeudCourant, _pointCourant);
            }
        }

        private void DessinObjets_MouseMove(object sender, MouseEventArgs e)
        {
            if (enDeplacement)
            {
                if (noeudCourant != null)
                {
                    noeudCourant.Move(new Point((int) ((e.Location.X - origin.X) / zoom), 
                                                (int) ((e.Location.Y - origin.Y) / zoom)));
                }
            }

            if (enDessin)
            {
                pointCourant = new Point((int) ((e.Location.X - origin.X) / zoom), 
                                         (int) ((e.Location.Y - origin.Y) / zoom));
            }

            Refresh();
        }

        private void DessinObjets_MouseUp(object sender, MouseEventArgs e)
        {
            if (enDessin)
            {
                Noeud trouve = TrouveNoeud(new Point((int) ((e.Location.X - origin.X) / zoom), 
                                                     (int) ((e.Location.Y - origin.Y) / zoom)));

                if(trouve == null)
                {
                    trouve = NoeudDefaut(new Point((int) ((e.Location.X - origin.X) / zoom), 
                                                   (int) ((e.Location.Y - origin.Y) / zoom)));
                    noeuds.Add(trouve);
                }

                Trait trait = new Trait(noeudCourant, trouve, Color.Red,1);
                traits.Add(trait);
                Refresh();
            }

            enDeplacement = false;
            enDessin = false;
            pointCourant = Point.Empty;
        }

        private void Plus_Click(object sender, EventArgs e)
        {
            if (epaisseurDefaut < 10)
            {
                epaisseurDefaut++;
                MoinsEpaisseur.Enabled = true;
            }
            else
            {
                PlusEpaisseur.Enabled = false;
                MessageBox.Show("Epaisseur maximal");
            }

        }

        private void Moins_Click(object sender, EventArgs e)
        {
            if (epaisseurDefaut > 1)
            {
                epaisseurDefaut--;
                PlusEpaisseur.Enabled = true;
            }
            else
            {
                MoinsEpaisseur.Enabled = false;
                MessageBox.Show("Epaisseur minimal");   
            }
        }

        private void couleurDefaut_Click(object sender, EventArgs e)
        {
            ColorDialog c = new ColorDialog();
            c.Color = couleurDefaut;
            if (c.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                couleurDefaut = c.Color;
            }
        }

        private void NewButton_Click(object sender, EventArgs e)
        {
            noeuds.Clear();
            traits.Clear();
            Refresh();
        }

        // Sauvegarder & lire des fichiers CSV
        /*
        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog svfd = new SaveFileDialog();
            svfd.Filter = "Fichier csv|*.csv";
            svfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (svfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(svfd.FileName);

                sw.WriteLine(noeuds.Count.ToString());
                foreach (Noeud noeud in noeuds)
                {
                    sw.Write(noeud.ToString());
                    sw.WriteLine();
                }

                sw.WriteLine(traits.Count.ToString());
                foreach (Trait trait in traits)
                {
                    sw.Write(trait.ToString());
                    sw.WriteLine();
                }

                sw.Close();
            }
        }

        private void OpenButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog opfd = new OpenFileDialog();
            opfd.Filter = "Fichier csv|*.csv";
            opfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (opfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                noeuds.Clear();
                traits.Clear();
                StreamReader sr = new StreamReader(opfd.FileName);
                string champ;

                // lecture des noeuds
                int nb_noeuds = int.Parse(sr.ReadLine());
                for( int i = 0 ; i < nb_noeuds && !sr.EndOfStream ; i++ )
                {
                    champ = sr.ReadLine();
                    Noeud n = new Noeud(champ);
                    noeuds.Add(n);
                }

                // lecture des traits
                int nb_traits = int.Parse(sr.ReadLine());
                for (int i = 0; i < nb_traits && !sr.EndOfStream ; i++)
                {
                    champ = sr.ReadLine();
                    Trait t = new Trait(champ, noeuds);

                    traits.Add(t);
                }

                sr.Close();
                Refresh();
            }
        }
        */

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog save_dia = new SaveFileDialog();
            save_dia.Filter = "Fichier XML|*.xml";
            if (save_dia.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(save_dia.FileName);
                sw.WriteLine("<!--?xml version=\"1.0\" encoding=\"UTF-8\" ?--> ");
                sw.WriteLine("<DESSIN>");

                foreach (Noeud n in noeuds)
                {
                    sw.WriteLine(n.ToXML());
                }

                foreach (Trait t in traits)
                {
                    sw.WriteLine(t.ToXML());
                }

                sw.WriteLine("</DESSIN>");
                sw.Close();
            }

        }

        private void OpenButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog op_dia = new OpenFileDialog();
            op_dia.Filter = "Fichier XML | *.xml";

            if (op_dia.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                noeuds.Clear();
                traits.Clear();

                XmlDocument doc = new XmlDocument();
                doc.Load(op_dia.FileName);

                foreach (XmlNode xN in doc.ChildNodes)
                {
                    if (xN.Name == "DESSIN")
                    {
                        foreach (XmlNode xNN in xN.ChildNodes)
                        {
                            if (xNN.Name == "NOEUD")
                            {
                                Noeud n = new Noeud(xNN);
                                noeuds.Add(n);
                            }
                            else if (xNN.Name == "TRAIT")
                            {
                                Trait t = new Trait(xNN, noeuds);
                                traits.Add(t);
                            }
                        }
                    }
                }

                Refresh();
            }
        }

        private void vScroll_Scroll(object sender, ScrollEventArgs e)
        {
            switch (e.Type)
            {
                case ScrollEventType.First: // le scroll bar se déplace à la position minimale
                    {
                        break;
                    }

                case ScrollEventType.Last: // le scroll bar se déplace à la position maximale
                    {
                        break;
                    }

                case ScrollEventType.EndScroll: // le scroll bar s'arrête à se déplacer
                    {
                        origin.Y = -e.NewValue;
                        vScroll.Value = e.NewValue;
                        break;
                    }
            }

            Refresh();
        }

        private void hScroll_Scroll(object sender, ScrollEventArgs e)
        {
            switch (e.Type)
            {
                case ScrollEventType.First: // le scroll bar se déplace à la position minimale
                    {
                        break;
                    }

                case ScrollEventType.Last: // le scroll bar se déplace à la position maximale
                    {
                        break;
                    }

                case ScrollEventType.EndScroll: // le scroll bar s'arrête à se déplacer
                    {
                        origin.X = -e.NewValue;
                        hScroll.Value = e.NewValue;
                        break;
                    }
            }

            Refresh();
        }

        private void DessinObjets_MouseWheel(object sender, MouseEventArgs e)
        {
            if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
            {
                if (e.Delta > 0)
                {
                    zoom *= 1.1f;
                    if (zoom > 15f) zoom = 15f;

                    // Les codes ci-dessous servent à tester si vScroll.Value dépasse vScroll.Maximum, mais ils ne marchent pas correctement
                    vScroll.Maximum *= (int)zoom;
                    if ((vScroll.Value * (int)zoom) < vScroll.Maximum)    vScroll.Value *= (int)zoom;
                    
                    // Même pour hScroll
                    hScroll.Maximum *= (int)zoom;
                    if ((hScroll.Value * (int)zoom) < hScroll.Maximum)    hScroll.Value *= (int)zoom;

                    origin.X *= (int)zoom;
                    origin.Y *= (int)zoom;
                }
                else if (e.Delta < 0)
                {
                    zoom /= 1.1f;
                    if (zoom < 1f) zoom = 1f;

                    vScroll.Maximum /= (int)zoom;
                    vScroll.Value /= (int)zoom;

                    hScroll.Maximum /= (int)zoom;
                    hScroll.Value /= (int)zoom;

                    origin.X /= (int)zoom;
                    origin.Y /= (int)zoom;
                }
            }

            Refresh();
        }

        private void DessinObjets_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                    /*
                case Keys.Down:
                    {
                        origin.Y -= vScroll.SmallChange;
                        break;
                    }

                case Keys.Up:
                    {
                        origin.Y += vScroll.SmallChange;
                        break;
                    }
                */
                    // les codes ci-dessus influencent au fonctionnement de zoom (+) et (-)

                case Keys.Right:
                    {
                        origin.X -= hScroll.SmallChange;
                        break;
                    }

                case Keys.Left:
                    {
                        origin.X += hScroll.SmallChange;
                        break;
                    }

                case Keys.PageDown:
                    {
                        origin.Y -= vScroll.LargeChange;
                        break;
                    }

                case Keys.PageUp:
                    {
                        origin.Y += vScroll.LargeChange;
                        break;
                    }
            }

            Refresh();
        }
    }
}
