#ifndef UTIL_H
#define UTIL_H
#include <iostream>
#include <string>
#include <sstream>

using namespace std;


std::string intToString(int);
void menu();

#endif
