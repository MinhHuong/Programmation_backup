#include "util.h"
#include <string>
#include <sstream>

int pgcd(int x, int y) {
  if (x == y)
    return x;
  if (x < 0)
    x *= (-1);
  if (y < 0)
    y *= (-1);
  if (x > y)
    return pgcd(y,x-y);
  else
    return pgcd(x,y-x);
}

string intToString(int x) {
  ostringstream oss;
  oss << x;
  string s = oss.str();
  return s;
}
