#include "Rationnel.h"
#include "util.h"

int main() {
  Rationnel r1(1,2);
  r1.affiche();

  Rationnel r2;
  r2.setNum(3);
  r2.setDeno(4);
  r2.affiche();
  r2.inverse(r2);
  r2.affiche();
  
  if (r1.egal(r2))
    cout << "r1 = r2" << endl;
  else
    cout << "r1 != r2" << endl;

  Rationnel s(1,1);
  r1.plus(r2,s);
  s.reduit();

  Rationnel d(1,1);
  r1.moins(r2,d);
  d.reduit();

  Rationnel p(1,1);
  r1.fois(r2,p);
  p.reduit();

  Rationnel q(1,1);
  r1.diviser(r2,q);
  q.reduit();
  q.toString();
  
}
