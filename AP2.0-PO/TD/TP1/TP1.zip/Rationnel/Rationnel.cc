#include "Rationnel.h"

Rationnel::Rationnel() {
  my_num = my_deno = 0;
}

Rationnel::Rationnel(int num, int deno) {
  my_num = num;
  if (deno != 0)
    my_deno = deno;
  else
    cout << "Erreur. Deno doit etre != 0" << endl;
}

void Rationnel::affiche() {
  cout << my_num << "/" << my_deno << endl;
}

void Rationnel::setNum(int num) {
  my_num = num;
}

void Rationnel::setDeno(int deno) {
  if (deno != 0)
    my_deno = deno;
  else
    cout << "Erreur. Deno doit etre != 0" << endl;
}

/*
Rationnel Rationnel::inverse() {
  int temp = my_num;
  my_num = my_deno;
  my_deno = temp;
  affiche();
  return *this;
}
*/

void Rationnel::inverse(Rationnel r) {
  int temp = r.my_num;
  r.my_num = r.my_deno;
  r.my_deno = temp;
  r.affiche();
}

bool Rationnel::egal(Rationnel r) {
  return (my_num == r.my_num) && (my_deno == r.my_deno);
}

void Rationnel::plus(const Rationnel & r, Rationnel & s) const {
  if (my_deno == r.my_deno)
    s.my_num = my_num + r.my_num;
  else {
    s.my_num = my_num*r.my_deno + r.my_num*my_deno;
    s.my_deno = my_deno*r.my_deno;
  }
  s.affiche();
}

void Rationnel::moins(const Rationnel & r, Rationnel & d) const {
  if (my_deno == r.my_deno)
    d.my_num = my_num - r.my_num;
  else {
    d.my_num = my_num*r.my_deno - r.my_num*my_deno;
    d.my_deno = my_deno*r.my_deno;
  }
  d.affiche();
}

void Rationnel::fois(const Rationnel & r, Rationnel & p) const {
  p.my_num = my_num * r.my_num;
  p.my_deno = my_deno * r.my_deno;
  p.affiche();
}

void Rationnel::diviser(const Rationnel & r, Rationnel & q) const {
  q.my_num = my_num * r.my_deno;
  q.my_deno = r.my_num * my_deno;
  q.affiche();
}

int Rationnel::getNum() {
  return my_num;
}

int Rationnel::getDeno() {
  return my_deno;
}

void Rationnel::reduit() {
  int res = pgcd(this->getNum(),this->getDeno());
  my_num = my_num/res;
  my_deno = my_deno/res;
  affiche();
}

string Rationnel::toString() {
  cout << intToString(my_num) << "/" << intToString(my_deno) << endl;
}

