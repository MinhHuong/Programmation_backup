#include "Complexe.h"

int main() {
  Complexe c1(1,2);
  c1.afficher();

  Complexe c2;
  c2.setReel(1.0/2.0);
  c2.setImaginaire(3.0/2.0);
  c2.afficher();

  Complexe s(1,1);
  c1.plus(c2,s);
  s.afficher();

  Complexe p(1,1);
  c1.fois(c2,p);
  p.afficher();
}
