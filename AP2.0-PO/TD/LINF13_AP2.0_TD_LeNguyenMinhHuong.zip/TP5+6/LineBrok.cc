#include "Screen.h"
#include "Point.h"
#include "Line.h"
#include "LineBrok.h"


LineBrok::LineBrok( char col, const Point & a, const Point & b, const Point & m )
  : Line( col, a, b )
{
  my_m = m;
}

LineBrok::~LineBrok()
{}

void 
LineBrok::move( int dx, int dy ) 
{
  Line::move( dx, dy );
  my_m.deplace( dx, dy );
}

void 
LineBrok::draw( Screen & s ) 
{ 
  char oldPen = s.getColPen();
  s.setColPen( my_col );

  s.put_line( my_w, my_m );
  s.put_line( my_m, my_e );
  
  s.setColPen( oldPen );
}

bool LineBrok::appartenir(const Point& p) const {
  int x1 = my_w.getX(), 
    x2 = my_e.getX(), 
    x3 = my_m.getX(),
    y1 = my_w.getY(),
    y2 = my_e.getY(),
    y3 = my_m.getY();
    
  int x_bg, y_bg, x_hd, y_hd;

  // Trouver le bas gauche
  x_bg = (x1 < x2)?x1:x2;
  x_bg = (x3 < x_bg)?x3:x_bg;
  
  y_bg = (y1 < y2)?y1:y2;
  y_bg = (y3 < y_bg)?y3:y_bg;

  //Trouver le haut droite
  x_hd = (x1 > x2)?x1:x2;
  x_hd = (x3 > x_hd)?x3:x_hd;

  y_hd = (y1 > y2)?y1:y2;
  y_hd = (y3 > y_hd)?y3:y_hd;

  int px = p.getX(), py = p.getY();

  if ( (px >= x_bg) &&
       (px <= x_hd) &&
       (py >= y_bg) &&
       (py <= y_hd) )
    return true;
  else
    return false;
}
