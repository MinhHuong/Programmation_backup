package pufhcm.votepourenfants.screen_voter;

import pufhcm.votepourenfants.R;




public class Voter_information {
	
	// references to our images
    public static final Integer[] ImageIds = {
            R.drawable.a,
            R.drawable.b, 
            R.drawable.c,
            R.drawable.d,
            R.drawable.e, 
            R.drawable.f,
            R.drawable.g,
            R.drawable.h, 
            R.drawable.i,
            R.drawable.j, 
            R.drawable.k,
            R.drawable.l, 
            R.drawable.m, 
            R.drawable.n,
            R.drawable.o,
            R.drawable.p
    };

    // references to the titles
    public static final String[] Voter_names = {
            "ANGEL",
            "HANDS",
            "Oh la la",
            "CRY",
            "CUTE",
            "Minh Huong",
            "Thanh Tam",
            "Trung Thang",
            "Trung Hieu",
            "Ba Loc",
            "Ngoc Long",
            "Hieu Tri",
            "Anh Trung",
            "BEAU",
            "NICOLAS",
            "DEVIL"
    };

}
