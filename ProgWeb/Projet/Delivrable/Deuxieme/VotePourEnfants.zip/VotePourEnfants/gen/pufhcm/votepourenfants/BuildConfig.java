/** Automatically generated file. DO NOT MODIFY */
package pufhcm.votepourenfants;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}